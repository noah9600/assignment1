module.exports = {
    sessionSecret: 'developmentSessionSecret'
};