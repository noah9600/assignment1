function changeTextColor() {
    var aboutMeSection = document.querySelector('.content');
    aboutMeSection.style.color = 'blue';
}